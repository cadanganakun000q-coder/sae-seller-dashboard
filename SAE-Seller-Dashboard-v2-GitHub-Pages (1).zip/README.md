# SAE Seller Dashboard v2

Rumus harga:
**(angka Income × Rate Income) + (angka Speed × Rate Speed)**

Contoh:
15 B/s dengan rate income Rp900 + 45 B dengan rate speed Rp400
= (15 × 900) + (45 × 400)
= **Rp31.500**

M/B hanya label game; yang dihitung hanya angka depannya.

Fitur v2:
- Rate Income/sec dan Speed terpisah.
- Rate dapat disembunyikan untuk screenshot.
- Edit spesifikasi tiap akun.
- Font dan ukuran angka diperbesar agar lebih mudah dibaca.
- Ready/Sold.
- Checkbox akun yang ikut/tidak ikut perhitungan.
- Hide semua nama dan password.
- Search, filter, sorting.
- Export/import backup JSON.
- Data tersimpan di browser (localStorage).
